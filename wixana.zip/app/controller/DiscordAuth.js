const { Client, IntentsBitField ,Partials } = require('discord.js');
require('dotenv').config();

exports.discordLogIn = async () => {
    const client = new Client({
        intents: [
            IntentsBitField.Flags.Guilds,
            IntentsBitField.Flags.MessageContent,
            IntentsBitField.Flags.GuildMessages,
            IntentsBitField.Flags.DirectMessages 
        ],
        partials: [Partials.Channel] 
    });

    const readyPromise = new Promise((resolve) => {
        client.on('ready', () => {
            console.log(`Discord logged in`);
            resolve();
        });
    });


    try {
        await client.login(process.env.TOKEN); // Login with the bot token
        await readyPromise;
        global.client = client;
    } catch (error) {
        console.error('Error logging in:', error);
    }
}
