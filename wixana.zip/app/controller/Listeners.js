const { findHeroNames, calculateActiveBlance, calculatePendingBlance, calculateLastMailedBalance, factor, createTextFile, calculatePaymentCharacter } = require('@root/app/utils/sheet.js');
const { addCommas } = require('@root/app/utils/general');
const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

exports.botInitListeners = async () => {
    global.client.on('messageCreate', async (message) => {
        if (message.author.bot) return;
        myHeros(message);
        balance(message);
        textFile(message);
    });
};


const myHeros = async (message) => {
    if (message.content !== '!myHeros') return;

    try {
        const discordID = message.author.id;


        const heroNames = await findHeroNames(discordID);

        if (heroNames.length > 0) {
            await message.author.send(`Here are your heroes: ${heroNames.join(', ')}`);
        } else {
            await message.author.send('No heroes found for your Discord ID.');
        }

    } catch (error) {
        console.error(`Failed to send DM: ${error}`);
    }
}

const balance = async (message) => {
    if (message.content !== '!balance') return;

    try {
        const discordID = message.author.id;

        // If the message is in a guild channel, inform the user the bot will send a DM
        if (message.channel.type !== 'dm') {
            await message.channel.send(`${message.author}, Sending your balance via DM!`);
        }

        const waitingMessage = await message.author.send('Please wait, calculating your balance...');

        // Calculate balances
        const activeBalance = addCommas(await calculateActiveBlance(discordID) + "");
        const pendingBlance = addCommas(await calculatePendingBlance(discordID) + "");
        const lastMailedBlance = addCommas(await calculateLastMailedBalance(discordID) + "");
        const paymentCharacter = addCommas(await calculatePaymentCharacter(discordID) + "");

        // Create the embed
        const embed = new EmbedBuilder()
            .setColor(0xFF0000)
            .setTitle('Wixana Guild')
            .setDescription(message.author.globalName + ' balance in Wixana Guild as follows')
            .setThumbnail(global.client.user.displayAvatarURL())
            .addFields(
                { name: 'Active Balance', value: activeBalance, inline: true },
                { name: 'Pending Balance', value: pendingBlance, inline: true },
                { name: 'Last Mailed Balance', value: lastMailedBlance, inline: true },
                { name: 'PaymentCharacter', value: paymentCharacter, inline: true },
            );

        // Edit the "please wait" message to include the balances
        await waitingMessage.edit({ content: 'Here is your balance:', embeds: [embed] });
    } catch (error) {
        console.error(`Failed to send DM: ${error}`);
    }
};


const textFile = async (message) => {
    if (message.content !== '!attendance') return;

    let waitingMessage; // Declare waitingMessage outside of try-catch

    try {
        const discordID = message.author.id;

        // If the message is in a guild channel, inform the user the bot will send a DM
        if (message.channel.type !== 'dm') {
            await message.channel.send(`${message.author}, Sending your attendance via DM!`);
        }

        // Send a "please wait" message in DM
        waitingMessage = await message.author.send('Please wait, calculating your balance...');

        // Fetch hero names
        const heroNames = await findHeroNames(discordID);

        if (heroNames.length === 0) {
            await waitingMessage.edit('You are not in the list!');
            return;
        }

        const sheetColumnMap = {
            'Active Balance': {
                searchColumn: 'Main Roster',
                targetColumn: '',
            },
            'Pending Balance': {
                searchColumn: 'Main Roster',
                targetColumn: 'Notes',
            },
            'Balance Archive': {
                searchColumn: 'Main Roster',
                targetColumn: 'Notes',
            },
        };

        // Fetch data for the text file
        const data = await factor(sheetColumnMap, heroNames);
        const folder_path = path.join(__dirname, "..", "temp");
        const filePath = await createTextFile(data, discordID, folder_path);

        // Send the file to the user
        await message.author.send({ files: [filePath] });

        // Edit the waiting message to notify that the file has been sent
        if (waitingMessage) {
            await waitingMessage.edit('Here is your attendance file:');
        }

        // Optionally, delete the waiting message after a few seconds instead of editing
        // setTimeout(() => waitingMessage.delete(), 5000); // Uncomment to delete the message after 5 seconds

        // Delete the file after sending
        fs.unlink(filePath, (err) => {
            if (err) {
                console.error(`Failed to delete file: ${err}`);
            }
        });

    } catch (error) {
        console.log(error);

        // Edit the waiting message with an error notice if the try block failed
        if (waitingMessage) {
            await waitingMessage.edit('An error occurred while generating your report. Please try again later.');
        }

        console.error(`Failed to send DM: ${error}`);
    }
};


